package com.example.grama_angana_app

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    private lateinit var db: DatabaseReference
    private val bookedDates = HashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val calendar = findViewById<CalendarView>(R.id.calendarView)
        val btnBook = findViewById<Button>(R.id.btnBook)
        val btnMaintenance = findViewById<Button>(R.id.btnMaintenance)
        val btnEvents = findViewById<Button>(R.id.btnEvents)

        // Initialize Firebase safely
        db = FirebaseDatabase.getInstance().reference.child("bookings")

        loadBookings()

        calendar.setOnDateChangeListener { _, y, m, d ->
            val date = "$d-${m + 1}-$y"

            if (bookedDates.contains(date)) {
                Toast.makeText(this, "Booked ❌", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Available ✅", Toast.LENGTH_SHORT).show()
            }
        }

        btnBook.setOnClickListener {
            startActivity(Intent(this, BookingActivity::class.java))
        }

        btnMaintenance.setOnClickListener {
            startActivity(Intent(this, MaintenanceActivity::class.java))
        }

        btnEvents.setOnClickListener {
            startActivity(Intent(this, EventActivity::class.java))
        }
    }

    private fun loadBookings() {
        db.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                bookedDates.clear()

                for (data in snapshot.children) {
                    val key = data.key
                    if (key != null) {   //  SAFE CHECK
                        bookedDates.add(key)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(
                    this@MainActivity,
                    "Database Error ❌",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}