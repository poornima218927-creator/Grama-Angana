package com.example.grama_angana_app

import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class MaintenanceActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maintenance)

        val container = findViewById<LinearLayout>(R.id.container)

        //  FIXED Firebase URL (IMPORTANT)
        val db = FirebaseDatabase
            .getInstance("https://gramaanganaapp-default-rtdb.asia-southeast1.firebasedatabase.app/")
            .getReference("maintenance")

        db.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                container.removeAllViews()

                //  DEBUG: Check if data is coming
                val debug = TextView(this@MaintenanceActivity)
                debug.text = "Count = ${snapshot.childrenCount}"
                debug.textSize = 18f
                container.addView(debug)

                //  If no data
                if (!snapshot.exists()) {
                    val tv = TextView(this@MaintenanceActivity)
                    tv.text = "No Firebase Data Found"
                    tv.textSize = 20f
                    tv.setTextColor(Color.RED)
                    container.addView(tv)
                    return
                }

                //  Loop through data
                for (item in snapshot.children) {

                    val name = item.key ?: ""

                    //  Safe conversion (no crash)
                    val collected = item.child("Collected").value?.toString()?.toIntOrNull() ?: 0
                    val target = item.child("Target").value?.toString()?.toIntOrNull() ?: 1

                    val progress = if (target > 0) (collected * 100) / target else 0

                    //  Card Layout
                    val card = LinearLayout(this@MaintenanceActivity)
                    card.orientation = LinearLayout.VERTICAL
                    card.setPadding(30, 30, 30, 30)

                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(0, 0, 0, 20)
                    card.layoutParams = params

                    //  Safe background
                    card.setBackgroundColor(Color.WHITE)
                    card.elevation = 8f

                    //  Emoji
                    val emoji = when (name.lowercase()) {
                        "bulbs" -> "💡"
                        "chairs" -> "🪑"
                        "fans" -> "🌀"
                        else -> "🔧"
                    }

                    //  Title
                    val title = TextView(this@MaintenanceActivity)
                    title.text = "$emoji ${name.replaceFirstChar { it.uppercase() }}"
                    title.textSize = 18f
                    title.setTextColor(Color.BLACK)

                    //  ProgressBar
                    val progressBar = ProgressBar(
                        this@MaintenanceActivity,
                        null,
                        android.R.attr.progressBarStyleHorizontal
                    )
                    progressBar.max = 100
                    progressBar.progress = progress

                    progressBar.progressTintList =
                        android.content.res.ColorStateList.valueOf(
                            if (progress >= 100) Color.GREEN else Color.parseColor("#4CAF50")
                        )

                    //  Amount
                    val amount = TextView(this@MaintenanceActivity)
                    amount.text = "₹$collected / ₹$target"
                    amount.textSize = 14f

                    //  Percentage
                    val percent = TextView(this@MaintenanceActivity)
                    percent.text = "$progress% completed"
                    percent.textSize = 13f
                    percent.setTextColor(Color.DKGRAY)

                    // Add views
                    card.addView(title)
                    card.addView(progressBar)
                    card.addView(amount)
                    card.addView(percent)

                    container.addView(card)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                val errorText = TextView(this@MaintenanceActivity)
                errorText.text = "Error: ${error.message}"
                errorText.setTextColor(Color.RED)
                container.addView(errorText)
            }
        })
    }
}