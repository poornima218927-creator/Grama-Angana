package com.example.grama_angana_app

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class EventActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event)

        val container = findViewById<LinearLayout>(R.id.eventContainer)

        val db = FirebaseDatabase.getInstance().reference.child("bookings")

        db.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                // Remove old views except title
                if (container.childCount > 1) {
                    container.removeViews(1, container.childCount - 1)
                }

                for (data in snapshot.children) {

                    val date = data.key
                    val name = data.value.toString()

                    // 🔥 Create Card Layout
                    val card = LinearLayout(this@EventActivity)
                    card.orientation = LinearLayout.VERTICAL
                    card.setPadding(30, 30, 30, 30)

                    val params = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    params.setMargins(0, 0, 0, 20)
                    card.layoutParams = params

                    card.setBackgroundResource(R.drawable.card_bg)
                    card.elevation = 8f

                    // 📅 Title
                    val title = TextView(this@EventActivity)
                    title.text = "📅 Booking"
                    title.textSize = 18f
                    title.setTextColor(resources.getColor(android.R.color.holo_purple))

                    // 📆 Date
                    val dateView = TextView(this@EventActivity)
                    dateView.textSize = 16f

                    val formattedDate = if (date != null && date.length == 8) {
                        val day = date.substring(0, 2)
                        val month = date.substring(2, 4)
                        val year = date.substring(4, 8)
                        "$day/$month/$year"
                    } else {
                        date
                    }

                    dateView.text = "Date: $formattedDate"

                    // 👤 Name
                    val nameView = TextView(this@EventActivity)
                    nameView.text = "Booked by: $name"
                    nameView.textSize = 16f

                    // Add views to card
                    card.addView(title)
                    card.addView(dateView)
                    card.addView(nameView)

                    // Add card to screen
                    container.addView(card)
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }
}