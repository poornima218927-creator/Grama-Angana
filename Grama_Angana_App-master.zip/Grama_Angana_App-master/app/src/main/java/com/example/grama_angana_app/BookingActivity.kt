package com.example.grama_angana_app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import com.google.firebase.database.FirebaseDatabase

class BookingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)

        val name = findViewById<EditText>(R.id.etName)
        val date = findViewById<EditText>(R.id.etDate)
        val btn = findViewById<Button>(R.id.btnSubmit)

        val db = FirebaseDatabase.getInstance().reference.child("bookings")

        // 🔔 Request permission (Android 13+)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        btn.setOnClickListener {

            val n = name.text.toString()
            val d = date.text.toString()

            if (n.isEmpty() || d.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            db.child(d).get().addOnSuccessListener {

                if (it.exists()) {
                    Toast.makeText(this, "Already Booked ❌", Toast.LENGTH_SHORT).show()

                    // 🔔 Notification for already booked
                    showNotification("This date is already booked ❌")

                } else {
                    db.child(d).setValue(n)
                    Toast.makeText(this, "Booking Success ✅", Toast.LENGTH_SHORT).show()

                    // 🔔 Notification for success
                    showNotification("Booking Confirmed for $d ✅")

                    finish()
                }
            }
        }
    }

    // 🔔 Notification function
    private fun showNotification(message: String) {

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "booking_channel"

        // Create channel (for Android 8+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Booking Notifications",
                NotificationManager.IMPORTANCE_HIGH
            )
            manager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Grama Angana")
            .setContentText(message)
            .setSmallIcon(R.mipmap.ic_launcher) // your app icon
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        manager.notify(1, builder.build())
    }
}